Getting started:

1. Install Maven from http://maven.apache.org

2. Import Maven project from IDE

2.1. For IntelliJ IDEA
- Select from menu File->New Project...
- Import Project from external model, select Maven

2.2. For Eclipse
- Select from menu File->Import
- From Import window select Maven->Existing Maven Projects

3. Run SnakeServlet as Java main class

4. Open in browser to see server in action
 http://localhost:8888/?board=*