package advisors

const explorerAttackRate = 2.0
const earlyExplorerMineConst = 3
const defenceAdvisorMineBonus = 20
