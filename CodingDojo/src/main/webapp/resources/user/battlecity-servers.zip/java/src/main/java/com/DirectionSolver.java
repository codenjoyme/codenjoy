package com;

import com.utils.BoardImpl;

/**
 * User: sanja
 * Date: 30.05.13
 * Time: 21:06
 */
public interface DirectionSolver {
    String get(BoardImpl board);
}
