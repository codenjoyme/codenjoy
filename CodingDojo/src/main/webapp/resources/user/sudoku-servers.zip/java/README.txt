Getting started:

1. Install Maven from http://maven.apache.org

2. Import Maven project from IDE

2.1. For IntelliJ IDEA
- Select from menu File->New Project...
- Import Project from external model, select Maven

2.2. For Eclipse
- Select from menu File->Import
- From Import window select Maven->Existing Maven Projects

3. If you play with http://codenjoy.com/codenjoy-contest/ then go to WebSocketRunner class

3.1 Use constant
  private static final String SERVER = "ws://tetrisj.jvmhost.net:12270/tetris-contest/ws";

3.2 Change your name (the same as for registration)
  private static String USER_NAME = "apofig"

3.3 Write your own logic at YourDirectionSolver class

3.4 And run as Java console application
