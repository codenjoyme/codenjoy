package com;

/**
 * User: sanja
 * Date: 21.04.13
 * Time: 3:13
 */
public class DirectionSolver {

    public Direction get(String board) {
        return Direction.ACT;
    }
}
