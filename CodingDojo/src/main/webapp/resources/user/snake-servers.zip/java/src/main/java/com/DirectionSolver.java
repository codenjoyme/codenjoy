package com;

/**
 * User: sanja
 * Date: 30.05.13
 * Time: 21:06
 */
public interface DirectionSolver {
    String get(Board board);
}
