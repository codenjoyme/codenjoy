package com;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * User: oleksandr.baglai
 * Date: 10/2/12
 * Time: 2:03 AM
 */
public class LengthToXYTest {

    @Test
    public void should() {
//        String board =
//                "****" +
//                "*X0*" +
//                "*@#*" +
//                "****";
//
//        LengthToXY xyl = new LengthToXY(board.length());
//        xyl.getXY()

    }

}
