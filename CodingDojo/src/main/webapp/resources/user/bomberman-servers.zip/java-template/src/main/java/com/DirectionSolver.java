package com;

import com.utils.Board;

/**
 * User: тут может быть твое имя
 */
public class DirectionSolver {

    public Direction get(Board board) {
        return Direction.ACT;
    }
}
