Getting started:
1. Install Node.js from http://nodejs.org/
2. Update Path System variable - add node.js root folder
3. Setup new node.js library - run
       npm install ws
4. Change variable at Runner.js
       var hostIp = 'server_host_ip'; // (use 'tetrisj.jvmhost.net' for game with http://codenjoy.com/codenjoy-contest)
5. Change your name at Runner.js
       var userName = 'apofig';
6. Write your own bomberman code at get function.
7. Run run-server.bat