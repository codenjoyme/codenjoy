//
//  PathObject.m
//  Bombermen
//
//  Created by Hell_Ghost on 16.09.13.
//
//

#import "PathObject.h"

@implementation PathObject
@synthesize node;
@synthesize parent;
@synthesize isOpen;
@synthesize g, f, h;

@end
