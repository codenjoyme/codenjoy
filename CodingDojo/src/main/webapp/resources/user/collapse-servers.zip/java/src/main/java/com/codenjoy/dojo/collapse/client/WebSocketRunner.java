package com.codenjoy.dojo.collapse.client;

import com.codenjoy.dojo.collapse.client.utils.BoardImpl;
import com.codenjoy.dojo.collapse.client.utils.RandomDice;
import org.eclipse.jetty.websocket.WebSocket;
import org.eclipse.jetty.websocket.WebSocketClientFactory;

import java.net.URI;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebSocketRunner {

    private static final String SERVER = "ws://tetrisj.jvmhost.net:12270/codenjoy-contest/ws";
    private static final String LOCAL = "ws://127.0.0.1:8080/codenjoy-contest/ws";
    private static String USER_NAME = "apofig";

    private WebSocket.Connection connection;
    private DirectionSolver solver;
    private WebSocketClientFactory factory;

    public WebSocketRunner(DirectionSolver solver) {
        this.solver = solver;
    }

    public static void main(String[] args) throws Exception {
        String host = SERVER;
        DirectionSolver mySolver = new YourDirectionSolver(new RandomDice());        

        System.out.printf("Connecting '%s' to '%s'...\n", USER_NAME, host);
        run(host, USER_NAME, mySolver);
    }

    private static void run(String server, String userName, DirectionSolver mySolver) throws Exception {
        final WebSocketRunner client = new WebSocketRunner(mySolver);
        client.start(server, userName);
        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                try {
                    client.stop();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void stop() throws Exception {
        connection.close();
        factory.stop();
    }

    private void start(String server, String userName) throws Exception {
        final Pattern urlPattern = Pattern.compile("^board=(.*)$");

        factory = new WebSocketClientFactory();
        factory.start();

        org.eclipse.jetty.websocket.WebSocketClient client = factory.newWebSocketClient();
        connection = client.open(new URI(server + "?user=" + userName), new WebSocket.OnTextMessage() {
            public void onOpen(Connection connection) {
                System.out.println("Opened");
            }

            public void onClose(int closeCode, String message) {
                System.out.println("Closed");
            }

            public void onMessage(String data) {
                System.out.println("data = " + data);
                try {
                    Matcher matcher = urlPattern.matcher(data);
                    if ( !matcher.matches()) {
                        throw new RuntimeException("WTF? " + data);
                    }
                    BoardImpl board = new BoardImpl(matcher.group(1));
                    String answer = solver.get(board);
                    connection.sendMessage(answer);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).get(5000, TimeUnit.MILLISECONDS);
    }
}
