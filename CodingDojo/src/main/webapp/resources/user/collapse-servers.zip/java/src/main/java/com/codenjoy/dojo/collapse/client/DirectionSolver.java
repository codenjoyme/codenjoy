package com.codenjoy.dojo.collapse.client;

import com.codenjoy.dojo.collapse.client.utils.BoardImpl;

public interface DirectionSolver {
    String get(BoardImpl board);
}
