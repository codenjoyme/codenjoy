package com.codenjoy.dojo.collapse.client.utils;

public interface Dice {
    int next(int max);
}
