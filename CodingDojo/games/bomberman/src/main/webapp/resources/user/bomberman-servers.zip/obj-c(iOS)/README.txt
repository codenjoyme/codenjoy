Getting started:
1. Install xCode if needed
2. Open Bombermen.xcodeproj
3. Change server URL if needed in BombermanAPI.m (row 33)
4. Statr following server with function [[BombermanAPI sharedApi] newGameWithUserName:@"Your username"];
