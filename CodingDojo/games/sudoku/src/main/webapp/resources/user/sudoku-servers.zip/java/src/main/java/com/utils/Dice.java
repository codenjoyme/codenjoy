package com.utils;

/**
 * User: sanja
 * Date: 17.08.13
 * Time: 16:42
 */
public interface Dice {
    int next(int max);
}
