Getting started:
1. Install Node.js from http://nodejs.org/
2. Update Path System variable - add node.js root folder
3. Run run-server.bat
4. Open in browser to see server in action
 http://localhost:8888/?figure=I&x=5&y=19