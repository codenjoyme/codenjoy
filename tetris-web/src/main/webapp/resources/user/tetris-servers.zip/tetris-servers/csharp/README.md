Welcome
=======
It is a testris template client project based on Nancy (http://www.nancyfx.org/).


Getting started 
---------------
* Install NuGet (from http://nuget.org/)
* Open the Solution in Visual Studio 2010 (at least Visual Studio Web Developer 2010 Express is required)
* To get Nancy
  * Go to Tool | Library Package Manager | Package Manager Console
  * Run: Install-Package Nancy.Hosting.Self
* Enjoy!  